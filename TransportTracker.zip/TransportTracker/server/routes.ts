import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertFavoriteSchema } from "@shared/schema";
import fetch from "node-fetch";

const TFL_API_KEY = "33be062d4b1d4427acf1870dcdf3091e";

// Simple hash function for passwords (not secure for production)
function hashPassword(password: string): string {
  return Buffer.from(password).toString('base64');
}

export async function registerRoutes(app: Express): Promise<Server> {
  // TfL API proxy routes
  app.get("/api/lines/:id/arrivals", async (req, res) => {
    const response = await fetch(
      `https://api.tfl.gov.uk/Line/${req.params.id}/Arrivals?app_key=${TFL_API_KEY}`
    );
    const data = await response.json();
    res.json(data);
  });

  app.get("/api/lines/status", async (_req, res) => {
    const response = await fetch(
      `https://api.tfl.gov.uk/Line/Mode/tube,dlr,overground,bus/Status?app_key=${TFL_API_KEY}`
    );
    const data = await response.json();
    res.json(data);
  });

  app.get("/api/stops/search", async (req, res) => {
    const query = encodeURIComponent(req.query.query as string);
    const response = await fetch(
      `https://api.tfl.gov.uk/StopPoint/Search/${query}?app_key=${TFL_API_KEY}`
    );
    if (!response.ok) {
      return res.status(response.status).json({ error: 'Failed to fetch stop points' });
    }
    const data = await response.json();
    res.json(data.matches || []);
  });

  app.get("/api/stops/:id/arrivals", async (req, res) => {
    const response = await fetch(
      `https://api.tfl.gov.uk/StopPoint/${req.params.id}/Arrivals?app_key=${TFL_API_KEY}`
    );
    const data = await response.json();
    res.json(data);
  });

  app.get("/api/vehicles/:ids/arrivals", async (req, res) => {
    try {
      const response = await fetch(
        `https://api.tfl.gov.uk/Vehicle/${encodeURIComponent(req.params.ids)}/Arrivals?app_key=${TFL_API_KEY}`
      );
      if (!response.ok) {
        throw new Error(`TfL API responded with status: ${response.status}`);
      }
      const data = await response.json();
      res.json(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('Vehicle API Error:', error);
      res.status(500).json({ error: 'Failed to fetch vehicle data' });
    }
  });

  app.get("/api/journey", async (req, res) => {
    const { from, to } = req.query;
    try {
      const response = await fetch(
        `https://api.tfl.gov.uk/Journey/JourneyResults/${encodeURIComponent(from as string)}/to/${encodeURIComponent(to as string)}?app_key=${TFL_API_KEY}`
      );
      if (!response.ok) {
        throw new Error(`TfL API responded with status: ${response.status}`);
      }
      const data = await response.json();
      res.json(data);
    } catch (error) {
      console.error('Journey API Error:', error);
      res.status(500).json({ error: 'Failed to fetch journey data' });
    }
  });

  // User routes
  app.post("/api/users", async (req, res) => {
    const parsed = insertUserSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error });
    }
    const user = await storage.createUser(parsed.data);
    res.json(user);
  });

  app.get("/api/users/:id", async (req, res) => {
    const user = await storage.getUser(parseInt(req.params.id));
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    res.json(user);
  });

  app.get("/api/users/:id/points", async (req, res) => {
    const user = await storage.getUser(parseInt(req.params.id));
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    res.json({ points: user.points });
  });

  // Favorites routes
  app.get("/api/users/:id/favorites", async (req, res) => {
    const favorites = await storage.getFavorites(parseInt(req.params.id));
    res.json(favorites);
  });

  app.post("/api/users/:id/favorites", async (req, res) => {
    const parsed = insertFavoriteSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error });
    }
    const favorite = await storage.addFavorite(parseInt(req.params.id), parsed.data);
    res.json(favorite);
  });

  app.delete("/api/users/:userId/favorites/:favoriteId", async (req, res) => {
    await storage.removeFavorite(
      parseInt(req.params.userId),
      parseInt(req.params.favoriteId)
    );
    res.status(204).end();
  });

  // Points history routes
  app.get("/api/users/:id/points/history", async (req, res) => {
    const history = await storage.getPointsHistory(parseInt(req.params.id));
    res.json(history);
  });

  app.post("/api/users/:id/notes", async (req, res) => {
    const { note } = req.body;
    // Here we would store the note in the database
    res.json({ success: true });
  });

  app.post("/api/users/:id/comments", async (req, res) => {
    const { comment } = req.body;
    // Here we would store the comment in the database
    res.json({ success: true });
  });

  // Register endpoint
  app.post("/api/register", async (req, res) => {
    try {
      const { username, password, displayName } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ error: "Username and password are required" });
      }
      
      // In a real app, check if user exists first
      
      // Create user with hashed password
      const user = await storage.createUser({
        username,
        password: hashPassword(password),
        displayName: displayName || username,
      });
      
      res.status(201).json({ 
        id: user.id,
        username: user.username,
        displayName: user.displayName,
        success: true
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ error: "Failed to register user" });
    }
  });
  
  // Login endpoint
  app.post("/api/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ error: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      
      if (!user || hashPassword(password) !== user.password) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      
      res.json({
        id: user.id,
        username: user.username,
        displayName: user.displayName,
        success: true
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to log in" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}