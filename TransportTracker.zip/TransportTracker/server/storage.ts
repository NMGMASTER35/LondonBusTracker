import { users, favorites, pointsHistory, notes, comments, type User, type InsertUser, type Favorite, type InsertFavoriteSchema, type PointsHistory, type Note, type Comment } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPoints(userId: number, points: number): Promise<User>;
  updateUserProfile(userId: number, data: Partial<User>): Promise<User>;
  getFavorites(userId: number): Promise<Favorite[]>;
  addFavorite(userId: number, favorite: InsertFavoriteSchema): Promise<Favorite>;
  removeFavorite(userId: number, favoriteId: number): Promise<void>;
  getPointsHistory(userId: number): Promise<PointsHistory[]>;
  addPointsHistory(userId: number, points: number, reason: string): Promise<PointsHistory>;
  getNotes(userId: number): Promise<Note[]>;
  addNote(userId: number, content: string): Promise<Note>;
  getComments(userId: number): Promise<Comment[]>;
  addComment(userId: number, content: string): Promise<Comment>;
  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private favorites: Map<number, Favorite>;
  private pointsHistory: Map<number, PointsHistory>;
  private notes: Map<number, Note>;
  private comments: Map<number, Comment>;
  private currentId: { 
    users: number; 
    favorites: number; 
    pointsHistory: number;
    notes: number;
    comments: number;
  };
  sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.favorites = new Map();
    this.pointsHistory = new Map();
    this.notes = new Map();
    this.comments = new Map();
    this.currentId = { 
      users: 1, 
      favorites: 1, 
      pointsHistory: 1,
      notes: 1,
      comments: 1
    };
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId.users++;
    const user: User = { 
      ...insertUser, 
      id, 
      points: 0, 
      darkMode: false,
      badges: [],
      level: 1,
      notificationsEnabled: true,
      displayName: insertUser.displayName || insertUser.username
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserProfile(userId: number, data: Partial<User>): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) throw new Error("User not found");

    const updatedUser = { ...user, ...data };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async updateUserPoints(userId: number, points: number): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) throw new Error("User not found");

    const updatedPoints = user.points + points;
    const newLevel = Math.floor(updatedPoints / 100) + 1;

    const updatedUser = { 
      ...user, 
      points: updatedPoints,
      level: newLevel
    };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async getFavorites(userId: number): Promise<Favorite[]> {
    return Array.from(this.favorites.values()).filter(
      (favorite) => favorite.userId === userId,
    );
  }

  async addFavorite(userId: number, favorite: InsertFavoriteSchema): Promise<Favorite> {
    const id = this.currentId.favorites++;
    const newFavorite: Favorite = { ...favorite, id, userId };
    this.favorites.set(id, newFavorite);
    return newFavorite;
  }

  async removeFavorite(userId: number, favoriteId: number): Promise<void> {
    const favorite = this.favorites.get(favoriteId);
    if (favorite && favorite.userId === userId) {
      this.favorites.delete(favoriteId);
    }
  }

  async getPointsHistory(userId: number): Promise<PointsHistory[]> {
    return Array.from(this.pointsHistory.values())
      .filter((history) => history.userId === userId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async addPointsHistory(userId: number, points: number, reason: string): Promise<PointsHistory> {
    const id = this.currentId.pointsHistory++;
    const history: PointsHistory = {
      id,
      userId,
      points,
      reason,
      timestamp: new Date(),
    };
    this.pointsHistory.set(id, history);
    return history;
  }

  async getNotes(userId: number): Promise<Note[]> {
    return Array.from(this.notes.values())
      .filter(note => note.userId === userId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async addNote(userId: number, content: string): Promise<Note> {
    const id = this.currentId.notes++;
    const note: Note = {
      id,
      userId,
      content,
      timestamp: new Date(),
    };
    this.notes.set(id, note);
    return note;
  }

  async getComments(userId: number): Promise<Comment[]> {
    return Array.from(this.comments.values())
      .filter(comment => comment.userId === userId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async addComment(userId: number, content: string): Promise<Comment> {
    const id = this.currentId.comments++;
    const comment: Comment = {
      id,
      userId,
      content,
      timestamp: new Date(),
    };
    this.comments.set(id, comment);
    return comment;
  }
}

export const storage = new MemStorage();