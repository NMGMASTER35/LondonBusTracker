
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { Label } from './components/ui/label';
import { useAuth } from './hooks/use-auth';

export default function TestAuth() {
  const { user, login, register, logout, isAuthenticated } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [isLogin, setIsLogin] = useState(true);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    try {
      let success;
      
      if (isLogin) {
        success = await login(username, password);
      } else {
        success = await register(username, password, displayName);
      }
      
      if (!success) {
        setError(isLogin ? 'Login failed' : 'Registration failed');
      }
    } catch (err) {
      setError('An error occurred');
      console.error(err);
    }
  };
  
  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>{isAuthenticated ? 'User Profile' : (isLogin ? 'Login' : 'Register')}</CardTitle>
      </CardHeader>
      <CardContent>
        {isAuthenticated ? (
          <div className="space-y-4">
            <div>
              <p><strong>Username:</strong> {user?.username}</p>
              <p><strong>Display Name:</strong> {user?.displayName}</p>
            </div>
            <Button onClick={logout} variant="outline">Logout</Button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            
            {!isLogin && (
              <div className="space-y-2">
                <Label htmlFor="displayName">Display Name (optional)</Label>
                <Input
                  id="displayName"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                />
              </div>
            )}
            
            {error && <p className="text-sm text-red-500">{error}</p>}
            
            <div className="flex flex-col space-y-2">
              <Button type="submit">
                {isLogin ? 'Login' : 'Register'}
              </Button>
              <Button 
                type="button" 
                variant="ghost" 
                onClick={() => setIsLogin(!isLogin)}
              >
                {isLogin ? 'Need an account? Register' : 'Already have an account? Login'}
              </Button>
            </div>
          </form>
        )}
      </CardContent>
    </Card>
  );
}
