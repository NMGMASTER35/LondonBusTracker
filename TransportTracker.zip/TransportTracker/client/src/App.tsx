import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Route, Router, Switch } from 'wouter';
import { SidebarProvider } from './hooks/use-sidebar';
import LiveArrivals from './pages/live-arrivals';
import LineInfo from './pages/line-info';
import AuthPage from './pages/auth-page';
import { AuthProvider } from './hooks/use-auth';
import Dashboard from './pages/dashboard';
import ServiceStatus from './pages/service-status';
import JourneyPlanner from './pages/journey-planner';
import Navbar from './components/layout/navbar';

const queryClient = new QueryClient();

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router>
          <div className="min-h-screen">
            <Navbar />
            <SidebarProvider>
              <div className="container mx-auto p-6">
                <Switch>
                  <Route path="/" component={Dashboard} />
                  <Route path="/auth" component={AuthPage} />
                  <Route path="/service-status" component={ServiceStatus} />
                  <Route path="/live-arrivals" component={LiveArrivals} />
                  <Route path="/line-info" component={LineInfo} />
                  <Route path="/journey-planner" component={JourneyPlanner} />
                </Switch>
              </div>
            </SidebarProvider>
          </div>
        </Router>
      </AuthProvider>
    </QueryClientProvider>
  );
}